import { fastify } from 'fastify'

import { getSlugFromString } from '../utils/getSlugFromString'
import { createdAt } from '../utils/createdAt'
import { request } from 'http'

const app = fastify()

app.get('/', () => {
  return 'Hello World'
})

interface PostData {
  title: string
  article: string
  category: string
  component: null
  published: boolean
}

app.post('/post', async (request, reply) => {
  const body = request.body as PostData

  const { title, article, category, component, published } = body

  const post = {
    title,
    slug: getSlugFromString(title),
    createdAt: createdAt(),
    article,
    category,
    component,
    published,
  }

  reply.send({
    ...post,
    statusCode: 200,
  })
})

app.get('/posts', async (request, reply) => {
    reply.send('posts')
})
app.get('/post', async (request, reply) => {
    reply.send('posts')
})

//works but is out of date: server.listen(3333)

//new way:
app
  .listen({
    port: 3333,
  })
  .then(() => console.log(`running on port 3333`))
