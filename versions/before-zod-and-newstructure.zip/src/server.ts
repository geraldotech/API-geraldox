import { fastify } from 'fastify'
import { openDb } from './configDB.js'

import { getSlugFromString } from '../utils/getSlugFromString.js'
import { createdAt } from '../utils/createdAt.js'
import { createTable, createPost, getPublishedPosts, singlePost } from './Controller/posts.js'

const app = fastify()

//createTable()

//openDb();

app.get('/', () => {
  return 'Hello World'
})

interface PostData {
  title: string
  article: string
  category: string
  author: string
  component: null
  published: boolean
}

app.post('/post', async (request, reply) => {
  const body = request.body as PostData

  const { title, article, category, component, published, author } = body

  const post = {
    title,
    slug: getSlugFromString(title),
    createdAt: createdAt(),
    article,
    author,
    category,
    component,
    published,
  }

  createPost(post)

  reply.status(201).send({"message" : "created" })
})

app.get('/posts', async (request, reply) => {
  const all = await getPublishedPosts()
  reply.send(all)
})
app.get('/post/:slug', async (request, reply) => {
  const {slug} = request.params
  
  const single = await singlePost(slug)

  reply.send(single)
})

//works but is out of date: server.listen(3333)

//new way:
app
  .listen({
    port: 3333,
  })
  .then(() => console.log(`running on port 3333`))
