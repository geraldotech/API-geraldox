import { openDb } from '../configDB.js'

/* export default async function createTable(){
  openDb().then(db => {
    db.exec('CREATE TABLE IF NOT EXISTS Posts (id INTEGER PRIMARY KEY, )')
  })
}

 */

export async function createTable() {
  try {
    // Open the SQLite database
    const db = await openDb()

    // Execute SQL command to create the table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS Posts (
        id INTEGER PRIMARY KEY,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        author TEXT NOT NULL,
        published BOOLEAN DEFAULT 0,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        article TEXT NOT NULL,
        category TEXT,
        vuecomponent TEXT
      )
    `)

    console.log('Table "Posts" created successfully')

    // Close the database connection
    await db.close()
  } catch (error) {
    console.error('Error creating table:', error.message)
  }
}

interface Post {
  title: string
  slug: string
  author: string
  published?: boolean
  article: string
  category?: string
  vuecomponent?: string
}

export async function createPost(post: Post) {
  //console.log(post)
  try {
    // Open the SQLite database
    const db = await openDb()

    // Prepare SQL statement
    const stmt = await db.prepare(`
    INSERT INTO Posts (title, slug, author, published, article, category, vuecomponent)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `)

    // Execute SQL statement with post data
    await stmt.run(
      post.title,
      post.slug,
      post.author,
      post.published || false, // Default to false if published is not provided
      post.article,
      post.category || null, // Use null if category is not provided
      post.vuecomponent || null // Use null if vuecomponent is not provided
    )

    // Finalize the statement
    await stmt.finalize()

    console.log('Post inserted successfully')

    // Close the database connection
    await db.close()
  } catch (error) {
    console.error('Error on create post')
  }
}

export async function getPublishedPosts() {
  try {
    // Open the SQLite database
    const db = await openDb()

    // Execute SQL query to select published posts
    const posts = await db.all('SELECT * FROM Posts WHERE published = 1')

    // Close the database connection
    await db.close()

    // Return the selected posts
    return posts
  } catch (error: any) {
    console.error('Error fetching published posts:', error.message)
    return [] // Return an empty array in case of error
  }
}

export async function singlePost(slug: string) {
  try {
    // Open the SQLite database
    const db = await openDb()

    // Execute SQL query to select a published post by slug
    const post = await db.get('SELECT * FROM Posts WHERE slug = ? AND published = 1', slug)

    // Close the database connection
    await db.close()

    // Return the selected post, or null if not found
    return post
  } catch (error: any) {
    console.error('Error fetching published post by slug:', error.message)
    return null // Return null in case of error
  }
}
